package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    RadioButton johnCena;
    RadioButton randyOrton;
    RadioButton romanReigns;
    TextView textview;
    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        johnCena = (RadioButton) findViewById(R.id.johnCena);
        randyOrton = (RadioButton) findViewById(R.id.randyOrton);
        romanReigns = (RadioButton) findViewById(R.id.romanReigns);
        submit = (Button) findViewById(R.id.submitButton);
        textview = (TextView) findViewById(R.id.textid);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (randyOrton.isChecked()) {
//                    selectedSuperStar = randyOrton.getText().toString();

                    String txtvStrVal = textview.getText().toString();
                    int txtvIntVal = Integer.parseInt(txtvStrVal);
                    txtvIntVal--;

                    textview.setText(txtvIntVal+"");

                } else if (johnCena.isChecked()) {
                    String txtvStrVal = textview.getText().toString();
                    int txtvIntVal = Integer.parseInt(txtvStrVal);
                    txtvIntVal++;

                    textview.setText(txtvIntVal+"");

                } else if (romanReigns.isChecked()) {
                    textview.setText("0");                }
//                Toast.makeText(getApplicationContext(), selectedSuperStar, Toast.LENGTH_LONG).show(); // print the value of selected super star
            }
        });
    }
}