package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void incrementValue(View v) {
        TextView myTextView = findViewById(R.id.viewid);

        String txtvStrVal = myTextView.getText().toString();
        int txtvIntVal = Integer.parseInt(txtvStrVal);
        txtvIntVal++;

        myTextView.setText(txtvIntVal+"");

    }

    public void decrementValue(View v) {
        TextView myTextView = findViewById(R.id.viewid);

        String txtvStrVal = myTextView.getText().toString();
        int txtvIntVal = Integer.parseInt(txtvStrVal);
        txtvIntVal--;

        myTextView.setText(txtvIntVal+"");

    }

    public void resetValue(View v) {
        TextView myTextView = findViewById(R.id.viewid);

        myTextView.setText("0");

    }
}