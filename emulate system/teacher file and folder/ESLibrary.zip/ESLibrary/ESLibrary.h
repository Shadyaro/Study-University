#ifndef ESLibrary_h
#define ESLibrary_h

#include "Arduino.h"

class ESLibrary
{
  public:
    ESLibrary (int pin);
    void dot();
    void dash();
  private:
    int _pin;
};

#endif